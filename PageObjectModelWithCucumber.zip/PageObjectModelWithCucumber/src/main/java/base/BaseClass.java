package base;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	  public String filename;
//    public ChromeDriver driver;
//	  own isolated copy
      private static final ThreadLocal<ChromeDriver> driver = new ThreadLocal<ChromeDriver>();
     
     public void set() {
    	 ChromeOptions option = new ChromeOptions();
         option.addArguments("guest");
 	     driver.set(new ChromeDriver(option));

 	}
 	
 	public ChromeDriver get() {
 		ChromeDriver chromeDriver = driver.get();
        return chromeDriver;
 	}
     @BeforeMethod	
     public void preconditions() {
    	set();
//     	ChromeOptions option = new ChromeOptions();
//        option.addArguments("guest");
//     	driver=new ChromeDriver(option);
        get().manage().window().maximize();
     	get().get("http://leaftaps.com/opentaps/");
     
     }

     @AfterMethod
     public void postconditions() {
     	get().close();
     }
     

     @DataProvider(name="fetchData")
    public String[][] sendData() throws IOException {
    	return ReadExcel.ReadData(filename);
    }
}
