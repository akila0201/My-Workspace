package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {
	
	@Then("It should navigate to home screen")
	public void it_should_navigate_to_home_screen() {
		System.out.println("login successful");
	}
	@But("It throws error message")
	public void verifyerrormsg() {
		System.out.println("it throws error message");
	}
	 @When("click on the crmsfalink")
	public MyHomePage clickCrmsfaLink() {
		get().findElement(By.linkText("CRM/SFA")).click();
		 return new MyHomePage();
	}

}
